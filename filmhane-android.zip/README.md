# Filmhane — Android projesi

Uygulamanın tamamı `app/src/main/assets/index.html` içinde. Bu proje onu kamera izni, galeriye kaydetme, paylaşma, titreşim ve ses tuşuyla çekim desteği olan bir Android uygulamasına çevirir.

## Bilgisayar olmadan APK (GitHub, telefondan da olur)

1. github.com'da yeni bir depo aç (ör. `filmhane`).
2. "uploading an existing file" bağlantısıyla `filmhane-android.zip` dosyasını yükle ve kaydet (Commit).
3. **Actions** sekmesi → "set up a workflow yourself" → içeriği silip `apk-olustur.yml` dosyasındaki metni yapıştır → Commit.
4. Derleme 3-5 dakika sürer. Bitince çalıştırmanın sayfasındaki **Artifacts** bölümünden `Filmhane-APK` dosyasını indir, zip'i aç, `app-debug.apk` dosyasını telefonda çalıştır ("bilinmeyen uygulamalara izin ver" sorulursa izin ver).

Zip yerine klasörü olduğu gibi yüklersen `.github/workflows/build.yml` zaten içinde, 3. adıma gerek kalmaz.

## Android Studio ile

1. Zip'i aç, klasörü Android Studio'da **Open** ile aç (Gradle 8.7 kendiliğinden iner).
2. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`

## Notlar

- En düşük Android sürümü 8.0 (API 26).
- Fotoğraflar galeride **Resimler / Filmhane** klasörüne kaydedilir.
- Arayüzü değiştirmek istersen yalnızca `index.html` dosyasını düzenle.
- Her GitHub derlemesi yeni bir hata ayıklama anahtarıyla imzalanır; yeni sürümü kurmadan önce eskisini kaldırman gerekebilir.
